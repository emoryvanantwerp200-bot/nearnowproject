﻿NearNow XML Feed Fix

Upload these files to the root of the GitHub repo and replace the existing files:
- app.js
- styles.css

This changes feed cards so users see readable previews in NearNow instead of opening raw RSS XML in a browser tab.
